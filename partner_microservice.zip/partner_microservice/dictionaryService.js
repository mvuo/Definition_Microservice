// 1. Open terminal and navigate to folder where file is downloaded
// 2. Type npm init to install node (Visit nodejs.org and install the latest version if you need)
// 3. Type npm install node-fetch if needed
// 4. To run the server, type node dictionaryService (or whatever the file was named) into the terminal.
// 5. With the microservice running, the user can access it by opening up a browser and entering the URL http://localhost:3000/definitions/{word}. Replace {word} with the word you need the defintion for.
// 6. After entering the URL into the browser with the specified word, the browser will display a JSON response containing the defintion.
// 7. The user may go back to the terminal and press Ctrl+C to close the server anytime!

const http = require('http');

async function startServer() {
  // Use dynamic import to load node-fetch
  const fetch = await import('node-fetch');

  const server = http.createServer(async (req, res) => {
    // Check if it's a GET request to the "/api/definitions" endpoint
    if (req.method === 'GET' && req.url.startsWith('/definitions')) {
      const word = req.url.split('/').pop();

      try {
        const apiUrl = `https://api.dictionaryapi.dev/api/v2/entries/en/${word}`;
        const response = await fetch.default(apiUrl); // Use fetch.default
        const data = await response.json();

        // Check if the API returned any data
        if (data) {
          const meanings = data[0].meanings.map((meaning) => {
            return {
              partOfSpeech: meaning.partOfSpeech,
              definitions: meaning.definitions.map((definition) => {
                return {
                  definition: definition.definition,
                  example: definition.example,
                  synonyms: definition.synonyms || [],
                  antonyms: definition.antonyms || [],
                };
              }),
            };
          });

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ word, meanings }));
        } else {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Word not found in the dictionary.' }));
        }
      } catch (error) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'An error occurred while fetching data from the API.' }));
      }
    } else {
      // Handle other routes or invalid requests
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Route not found.' }));
    }
  });

  const PORT = 3000;
  server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Error starting the server:', error);
});
